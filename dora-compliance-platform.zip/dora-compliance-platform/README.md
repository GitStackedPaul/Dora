# DORA Compliance Platform

A professional DORA (Digital Operational Resilience Act) compliance gap analyzer for financial services SMEs in the Netherlands.

**Regulation:** EU 2022/2554 · Level 1 obligations (Articles 5–30)

## Features

- 🔍 **Gap Analysis** — 18 DORA Level 1 obligations with No gap / Partial gap / Gap status
- 📊 **Stats Dashboard** — Real-time compliance score, progress bar, stat cards
- 🗺️ **Improvement Roadmap** — Prioritised by severity with RTS/ITS references
- 📁 **Document Upload** — Drag & drop policy files; tags inferred from filenames
- 🏢 **Client Profiles** — Standard regime vs Micro Entity (Art. 4 proportionality)
- 📤 **JSON Export** — Export gap results for reporting

## Quick Start

```bash
# Install dependencies
npm install

# Start dev server
npm run dev

# Build for production
npm run build
```

Then open http://localhost:5173

## Project Structure

```
src/
├── App.jsx                    # Root component & state management
├── main.jsx                   # React entry point
├── index.css                  # Global styles
├── data/
│   └── obligations.js         # DORA obligations + TAG_MAP + sample docs
├── lib/
│   └── gapAnalysis.js         # Gap analysis engine (mirrors Node.js backend)
└── components/
    ├── Navbar.jsx              # Top navigation + profile toggle + export
    ├── Sidebar.jsx             # Search + filters + doc list
    ├── StatsBar.jsx            # Stat cards + progress bar
    ├── GapTable.jsx            # Main obligations table with expand rows
    ├── RoadmapTab.jsx          # Prioritised improvement roadmap
    ├── UploadTab.jsx           # Drag-and-drop document upload
    ├── Badges.jsx              # GapBadge, SeverityBadge, ApplicabilityBadge
    └── Icons.jsx               # Inline SVG icon components
```

## DORA Articles Covered

| Articles | Area |
|----------|------|
| 5–10 | ICT risk management framework, systems, protection, detection |
| 11–15 | Business continuity, backup, training, communication, incident management |
| 16–17 | Simplified framework, incident reporting |
| 19, 21 | Resilience testing, TLPT |
| 25–26, 30 | ICT third-party risk, register, contractual provisions |

## Client Profiles

- **Standard** — Full DORA regime
- **Micro Entity** — Proportional exemptions for entities with <10 staff and ≤€2M turnover (DORA Article 4(6))

## Tag Inference

Filenames are matched against a keyword map to infer DORA tags automatically:

| Keyword | Tags |
|---------|------|
| `risk` | risk, ict |
| `incident` | incident |
| `backup`, `recovery` | backup, recovery, bcp |
| `outsourcing` | third party, outsourcing, procurement |
| `training` | training, awareness |
| `business continuity` | bcp, continuity, drp |
| `information security` | security, ict, access |

## Legal Reference

- [DORA Regulation (EU) 2022/2554](https://eur-lex.europa.eu/legal-content/EN/TXT/?uri=CELEX%3A32022R2554)
- RTS on ICT risk management — EU 2024/1774
- RTS on incident reporting — EU 2025/301
- RTS on third-party risk — EU 2024/1773
- ITS on third-party arrangements — EU 2024/2956

## License

MIT
