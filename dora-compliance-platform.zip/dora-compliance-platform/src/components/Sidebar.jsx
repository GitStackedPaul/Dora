import { SearchIcon, FilterIcon, FileIcon } from './Icons.jsx';
import { GAP_CONFIG, SEV_CONFIG } from './Badges.jsx';

export default function Sidebar({
  searchQuery, setSearchQuery,
  gapFilter, toggleGapFilter,
  severityFilter, toggleSevFilter,
  gapResults, uploadedDocs,
  onClearFilters,
}) {
  const hasFilters = gapFilter.length > 0 || severityFilter.length > 0 || searchQuery;

  return (
    <aside style={{
      width: 220, background: "#161b22", borderRight: "1px solid #21262d",
      padding: "20px 14px", display: "flex", flexDirection: "column",
      gap: 24, flexShrink: 0, overflowY: "auto",
    }}>
      {/* Search */}
      <div>
        <SectionLabel>Search</SectionLabel>
        <div style={{ position: "relative" }}>
          <span style={{
            position: "absolute", left: 8, top: "50%",
            transform: "translateY(-50%)", color: "#8b949e", pointerEvents: "none",
          }}>
            <SearchIcon size={12} />
          </span>
          <input
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Article or keyword..."
            style={{
              width: "100%", padding: "6px 8px 6px 26px", borderRadius: 6,
              border: "1px solid #30363d", background: "#0d1117",
              color: "#e6edf3", fontSize: 12, outline: "none",
              transition: "border-color 0.15s",
            }}
            onFocus={(e) => { e.target.style.borderColor = "rgba(88,166,255,0.5)"; }}
            onBlur={(e) => { e.target.style.borderColor = "#30363d"; }}
          />
        </div>
      </div>

      {/* Gap Status Filter */}
      <div>
        <SectionLabel icon={<FilterIcon size={10} />}>Gap Status</SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {["No gap", "Partial gap", "Gap", "N/A"].map((g) => {
            const cfg = GAP_CONFIG[g];
            const active = gapFilter.includes(g);
            const count = gapResults.filter((r) => r.gap === g).length;
            return (
              <button
                key={g}
                onClick={() => toggleGapFilter(g)}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "5px 8px", borderRadius: 5, fontSize: 11,
                  border: active ? `1px solid ${cfg.border}` : "1px solid transparent",
                  background: active ? cfg.bg : "transparent",
                  color: active ? cfg.text : "#8b949e",
                  cursor: "pointer", fontWeight: active ? 600 : 400,
                  textAlign: "left", transition: "all 0.12s ease",
                }}
              >
                <span style={{ display: "flex", alignItems: "center", gap: 5 }}>
                  {cfg.icon} {g}
                </span>
                <CountPill>{count}</CountPill>
              </button>
            );
          })}
        </div>
      </div>

      {/* Severity Filter */}
      <div>
        <SectionLabel>Severity</SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
          {["High", "Medium", "Low"].map((s) => {
            const cfg = SEV_CONFIG[s];
            const active = severityFilter.includes(s);
            const count = gapResults.filter(
              (r) => r.gap_severity === s && r.applicability === "Applicable"
            ).length;
            return (
              <button
                key={s}
                onClick={() => toggleSevFilter(s)}
                style={{
                  display: "flex", alignItems: "center", justifyContent: "space-between",
                  padding: "5px 8px", borderRadius: 5, fontSize: 11,
                  border: active ? `1px solid ${cfg.color}40` : "1px solid transparent",
                  background: active ? cfg.bg : "transparent",
                  color: active ? cfg.color : "#8b949e",
                  cursor: "pointer", fontWeight: active ? 600 : 400,
                  transition: "all 0.12s ease",
                }}
              >
                <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span style={{
                    width: 7, height: 7, borderRadius: "50%", flexShrink: 0,
                    background: active ? cfg.color : "#484f58",
                    transition: "background 0.12s",
                  }} />
                  {s}
                </span>
                <CountPill>{count}</CountPill>
              </button>
            );
          })}
        </div>
      </div>

      {/* Documents list */}
      <div style={{ flex: 1, minHeight: 0 }}>
        <SectionLabel>
          Policy Docs ({uploadedDocs.length})
        </SectionLabel>
        <div style={{ display: "flex", flexDirection: "column", gap: 2 }}>
          {uploadedDocs.map((d, i) => (
            <div
              key={i}
              title={d.filename}
              style={{
                display: "flex", alignItems: "center", gap: 5,
                padding: "3px 5px", borderRadius: 4, fontSize: 10,
                color: "#8b949e",
              }}
            >
              <FileIcon size={10} />
              <span style={{ overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {d.filename}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Clear filters */}
      {hasFilters && (
        <button
          onClick={onClearFilters}
          style={{
            padding: "5px 10px", borderRadius: 5, fontSize: 11,
            border: "1px solid #30363d", background: "transparent",
            color: "#8b949e", cursor: "pointer",
          }}
        >
          ✕ Clear filters
        </button>
      )}
    </aside>
  );
}

function SectionLabel({ children, icon }) {
  return (
    <div style={{
      fontSize: 10, fontWeight: 600, color: "#8b949e",
      textTransform: "uppercase", letterSpacing: "0.08em",
      marginBottom: 8, display: "flex", alignItems: "center", gap: 4,
    }}>
      {icon} {children}
    </div>
  );
}

function CountPill({ children }) {
  return (
    <span style={{
      fontSize: 10, background: "#21262d", borderRadius: 10,
      padding: "0 5px", color: "#8b949e", minWidth: 18, textAlign: "center",
    }}>
      {children}
    </span>
  );
}
