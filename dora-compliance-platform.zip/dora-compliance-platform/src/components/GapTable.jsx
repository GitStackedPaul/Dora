import { useState } from 'react';
import { GapBadge, SeverityBadge, ApplicabilityBadge, GAP_CONFIG } from './Badges.jsx';
import { FileIcon, ChevronDownIcon } from './Icons.jsx';

const COLS = "80px 1fr 118px 190px 108px 88px 32px";

export default function GapTable({ rows }) {
  const [expandedRow, setExpandedRow] = useState(null);

  const toggle = (code) =>
    setExpandedRow((prev) => (prev === code ? null : code));

  return (
    <div style={{
      background: "#161b22", border: "1px solid #21262d",
      borderRadius: 10, overflow: "hidden",
    }}>
      {/* Header */}
      <div style={{
        display: "grid", gridTemplateColumns: COLS,
        padding: "9px 16px", background: "#0d1117",
        borderBottom: "1px solid #21262d", gap: 8,
      }}>
        {["Code", "Obligation", "Applicability", "Documentation", "Gap Status", "Severity", ""].map((h) => (
          <div key={h} style={{
            fontSize: 10, fontWeight: 600, color: "#8b949e",
            textTransform: "uppercase", letterSpacing: "0.06em",
          }}>
            {h}
          </div>
        ))}
      </div>

      {/* Body */}
      {rows.length === 0 ? (
        <div style={{ padding: 40, textAlign: "center", color: "#8b949e", fontSize: 13 }}>
          No obligations match the current filters.
        </div>
      ) : (
        rows.map((row, idx) => {
          const isExpanded = expandedRow === row.item_code;
          const isLast = idx === rows.length - 1;
          return (
            <div key={row.item_code}>
              {/* Main row */}
              <div
                onClick={() => toggle(row.item_code)}
                style={{
                  display: "grid", gridTemplateColumns: COLS,
                  padding: "10px 16px", gap: 8, cursor: "pointer",
                  background: isExpanded ? "rgba(88,166,255,0.04)" : "transparent",
                  borderBottom: isExpanded ? "none" : !isLast ? "1px solid #21262d" : "none",
                  alignItems: "center", transition: "background 0.1s",
                }}
                onMouseOver={(e) => {
                  if (!isExpanded) e.currentTarget.style.background = "rgba(88,166,255,0.03)";
                }}
                onMouseOut={(e) => {
                  if (!isExpanded) e.currentTarget.style.background = "transparent";
                }}
              >
                {/* Code */}
                <div style={{
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontSize: 11, color: "#58a6ff", fontWeight: 600,
                }}>
                  {row.item_code}
                </div>

                {/* Label */}
                <div>
                  <div style={{ fontSize: 12, color: "#e6edf3", fontWeight: 500 }}>
                    {row.item_label_en}
                  </div>
                  <div style={{ fontSize: 10, color: "#8b949e", marginTop: 2 }}>
                    {row.item_label_nl}
                  </div>
                </div>

                {/* Applicability */}
                <div>
                  <ApplicabilityBadge applicability={row.applicability} />
                </div>

                {/* Documentation */}
                <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                  {row.documentation.length === 0 ? (
                    <span style={{ fontSize: 10, color: "#484f58", fontStyle: "italic" }}>
                      No docs found
                    </span>
                  ) : (
                    <>
                      {row.documentation.slice(0, 2).map((d, i) => (
                        <span key={i} style={{
                          fontSize: 10, padding: "1px 6px", borderRadius: 4,
                          background: "#21262d", color: "#8b949e",
                          border: "1px solid #30363d",
                          display: "flex", alignItems: "center", gap: 3,
                          maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis",
                          whiteSpace: "nowrap",
                        }} title={d.filename}>
                          <FileIcon size={9} />
                          {d.filename.length > 22 ? d.filename.slice(0, 22) + "…" : d.filename}
                        </span>
                      ))}
                      {row.documentation.length > 2 && (
                        <span style={{ fontSize: 10, color: "#8b949e", alignSelf: "center" }}>
                          +{row.documentation.length - 2}
                        </span>
                      )}
                    </>
                  )}
                </div>

                {/* Gap badge */}
                <div><GapBadge gap={row.gap} /></div>

                {/* Severity */}
                <div><SeverityBadge sev={row.gap_severity} /></div>

                {/* Chevron */}
                <div style={{ color: "#8b949e", display: "flex", justifyContent: "center" }}>
                  <ChevronDownIcon
                    size={12}
                    style={{
                      transform: isExpanded ? "rotate(180deg)" : "rotate(0deg)",
                      transition: "transform 0.2s ease",
                    }}
                  />
                </div>
              </div>

              {/* Expanded detail */}
              {isExpanded && (
                <ExpandedDetail row={row} isLast={isLast} />
              )}
            </div>
          );
        })
      )}
    </div>
  );
}

function ExpandedDetail({ row, isLast }) {
  const borderColor = GAP_CONFIG[row.gap]?.border || "#30363d";
  return (
    <div style={{
      padding: "14px 16px 14px 96px",
      background: "rgba(88,166,255,0.025)",
      borderTop: "1px solid #21262d",
      borderBottom: !isLast ? "1px solid #21262d" : "none",
      animation: "slideDown 0.15s ease",
    }}>
      <style>{`@keyframes slideDown { from { opacity:0; transform:translateY(-4px); } to { opacity:1; transform:translateY(0); } }`}</style>

      {row.improvement_step_en ? (
        <>
          <div style={{
            fontSize: 10, fontWeight: 600, color: "#8b949e",
            textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 7,
          }}>
            Improvement Step
          </div>
          <div style={{
            fontSize: 12, color: "#c9d1d9", lineHeight: 1.65,
            background: "#0d1117", padding: "10px 14px", borderRadius: 6,
            border: "1px solid #21262d",
            borderLeft: `3px solid ${borderColor}`,
          }}>
            {row.improvement_step_en}
          </div>

          {row.documentation.length > 0 && (
            <div style={{ marginTop: 10 }}>
              <div style={{
                fontSize: 10, fontWeight: 600, color: "#8b949e",
                textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 6,
              }}>
                Supporting Documents
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
                {row.documentation.map((d, i) => (
                  <span key={i} style={{
                    fontSize: 11, padding: "3px 8px", borderRadius: 5,
                    background: "#21262d", color: "#8b949e",
                    border: "1px solid #30363d",
                    display: "flex", alignItems: "center", gap: 4,
                  }}>
                    <FileIcon size={10} /> {d.filename}
                  </span>
                ))}
              </div>
            </div>
          )}

          <div style={{ marginTop: 10 }}>
            <div style={{
              fontSize: 10, fontWeight: 600, color: "#8b949e",
              textTransform: "uppercase", letterSpacing: "0.07em", marginBottom: 6,
            }}>
              Gap Reason
            </div>
            <div style={{ fontSize: 11, color: "#8b949e" }}>{row.gap_reason_en}</div>
          </div>
        </>
      ) : (
        <div style={{ fontSize: 12, color: "#8b949e" }}>
          {row.gap === "N/A"
            ? "Not applicable under DORA Article 4 proportionality for micro entities."
            : "No improvement steps required — obligation appears to be well covered by existing documentation."}
        </div>
      )}
    </div>
  );
}
