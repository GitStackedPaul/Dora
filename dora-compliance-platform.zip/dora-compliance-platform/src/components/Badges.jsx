import { CheckCircleIcon, AlertTriangleIcon, XCircleIcon } from './Icons.jsx';

export const GAP_CONFIG = {
  "No gap": {
    bg: "rgba(63,185,80,0.12)",
    border: "rgba(63,185,80,0.4)",
    text: "#3fb950",
    icon: <CheckCircleIcon size={11} />,
  },
  "Partial gap": {
    bg: "rgba(227,179,65,0.12)",
    border: "rgba(227,179,65,0.4)",
    text: "#e3b341",
    icon: <AlertTriangleIcon size={11} />,
  },
  Gap: {
    bg: "rgba(248,81,73,0.12)",
    border: "rgba(248,81,73,0.4)",
    text: "#f85149",
    icon: <XCircleIcon size={11} />,
  },
  "N/A": {
    bg: "rgba(139,148,158,0.1)",
    border: "rgba(139,148,158,0.25)",
    text: "#8b949e",
    icon: null,
  },
};

export const SEV_CONFIG = {
  High:   { color: "#f85149", bg: "rgba(248,81,73,0.1)" },
  Medium: { color: "#e3b341", bg: "rgba(227,179,65,0.1)" },
  Low:    { color: "#3fb950", bg: "rgba(63,185,80,0.1)" },
  "N/A":  { color: "#8b949e", bg: "rgba(139,148,158,0.08)" },
};

export function GapBadge({ gap }) {
  const cfg = GAP_CONFIG[gap] || GAP_CONFIG["N/A"];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 4,
      padding: "2px 8px", borderRadius: 20, fontSize: 11, fontWeight: 600,
      background: cfg.bg, border: `1px solid ${cfg.border}`, color: cfg.text,
      letterSpacing: "0.01em", whiteSpace: "nowrap",
    }}>
      {cfg.icon} {gap}
    </span>
  );
}

export function SeverityBadge({ sev }) {
  const cfg = SEV_CONFIG[sev] || SEV_CONFIG["N/A"];
  return (
    <span style={{
      display: "inline-flex", alignItems: "center", gap: 5,
      padding: "2px 8px", borderRadius: 4, fontSize: 11, fontWeight: 600,
      background: cfg.bg, color: cfg.color, whiteSpace: "nowrap",
    }}>
      <span style={{
        width: 6, height: 6, borderRadius: "50%",
        background: cfg.color, display: "inline-block", flexShrink: 0,
      }} />
      {sev}
    </span>
  );
}

export function ApplicabilityBadge({ applicability }) {
  const isApplicable = applicability === "Applicable";
  return (
    <span style={{
      fontSize: 10, padding: "2px 8px", borderRadius: 20, fontWeight: 600,
      background: isApplicable ? "rgba(88,166,255,0.1)" : "rgba(139,148,158,0.08)",
      border: `1px solid ${isApplicable ? "rgba(88,166,255,0.3)" : "rgba(139,148,158,0.2)"}`,
      color: isApplicable ? "#58a6ff" : "#8b949e",
      whiteSpace: "nowrap",
    }}>
      {isApplicable ? "Applicable" : "Not Applicable"}
    </span>
  );
}
