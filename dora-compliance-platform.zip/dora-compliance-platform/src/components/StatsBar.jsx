export default function StatsBar({ stats }) {
  const scorePercent = Math.round((stats.noGap / (stats.total || 1)) * 100);
  const scoreColor = scorePercent >= 70 ? "#3fb950" : scorePercent >= 40 ? "#e3b341" : "#f85149";

  const cards = [
    { label: "Applicable",   value: stats.total,    color: "#58a6ff", sub: "obligations" },
    { label: "Compliant",    value: stats.noGap,    color: "#3fb950", sub: "no gap" },
    { label: "Partial Gap",  value: stats.partial,  color: "#e3b341", sub: "review needed" },
    { label: "Gap",          value: stats.gaps,     color: "#f85149", sub: "action required" },
    { label: "Score",        value: `${scorePercent}%`, color: scoreColor, sub: "compliance" },
  ];

  return (
    <div style={{ marginBottom: 20 }}>
      {/* Stat cards */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(5, 1fr)",
        gap: 12,
        marginBottom: 16,
      }}>
        {cards.map((c) => (
          <div
            key={c.label}
            style={{
              background: "#161b22", borderRadius: 10, padding: "14px 18px",
              border: "1px solid #21262d", display: "flex", flexDirection: "column",
              gap: 4, transition: "all 0.2s ease",
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.transform = "translateY(-1px)";
              e.currentTarget.style.borderColor = "rgba(88,166,255,0.25)";
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.transform = "translateY(0)";
              e.currentTarget.style.borderColor = "#21262d";
            }}
          >
            <div style={{ fontSize: 10, color: "#8b949e", fontWeight: 500 }}>{c.label}</div>
            <div style={{
              fontSize: 26, fontWeight: 700, color: c.color,
              fontFamily: "'IBM Plex Mono', monospace", lineHeight: 1.1,
            }}>
              {c.value}
            </div>
            <div style={{ fontSize: 10, color: "#484f58" }}>{c.sub}</div>
          </div>
        ))}
      </div>

      {/* Progress bar */}
      <div>
        <div style={{
          display: "flex", justifyContent: "space-between",
          marginBottom: 5, fontSize: 10, color: "#8b949e",
        }}>
          <span>Compliance Coverage</span>
          <span>{scorePercent}%</span>
        </div>
        <div style={{ height: 4, background: "#21262d", borderRadius: 2, overflow: "hidden" }}>
          <div style={{
            height: "100%", borderRadius: 2,
            background: `linear-gradient(90deg, #f85149 0%, #e3b341 40%, #3fb950 100%)`,
            width: `${scorePercent}%`,
            transition: "width 0.6s cubic-bezier(0.16,1,0.3,1)",
          }} />
        </div>
        <div style={{
          display: "flex", gap: 16, marginTop: 6,
          fontSize: 10, color: "#8b949e",
        }}>
          <span><span style={{ color: "#3fb950" }}>■</span> No Gap: {stats.noGap}</span>
          <span><span style={{ color: "#e3b341" }}>■</span> Partial: {stats.partial}</span>
          <span><span style={{ color: "#f85149" }}>■</span> Gap: {stats.gaps}</span>
          <span><span style={{ color: "#484f58" }}>■</span> N/A: {stats.notApplicable}</span>
        </div>
      </div>
    </div>
  );
}
