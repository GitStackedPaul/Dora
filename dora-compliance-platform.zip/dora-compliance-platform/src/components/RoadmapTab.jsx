import { GapBadge, SeverityBadge, SEV_CONFIG } from './Badges.jsx';

export default function RoadmapTab({ roadmap }) {
  if (roadmap.length === 0) {
    return (
      <div style={{
        padding: 60, textAlign: "center", color: "#8b949e",
        background: "#161b22", borderRadius: 10,
        border: "1px solid #21262d", fontSize: 14,
      }}>
        🎉 No gaps found — fully compliant!
      </div>
    );
  }

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      <div style={{ fontSize: 12, color: "#8b949e", marginBottom: 4 }}>
        {roadmap.length} improvement{roadmap.length !== 1 ? "s" : ""} prioritised by severity
      </div>
      {roadmap.map((r, i) => {
        const cfg = SEV_CONFIG[r.gap_severity];
        return (
          <div
            key={r.item_code}
            style={{
              background: "#161b22", borderRadius: 10,
              border: "1px solid #21262d",
              borderLeft: `3px solid ${cfg.color}`,
              padding: "14px 18px",
              display: "flex", gap: 16, alignItems: "flex-start",
              transition: "border-color 0.2s",
            }}
            onMouseOver={(e) => { e.currentTarget.style.borderTopColor = `${cfg.color}40`; }}
            onMouseOut={(e) => { e.currentTarget.style.borderTopColor = "#21262d"; }}
          >
            {/* Phase number */}
            <div style={{
              width: 28, height: 28, borderRadius: "50%", flexShrink: 0,
              background: cfg.bg, border: `1px solid ${cfg.color}40`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 700, color: cfg.color,
              fontFamily: "'IBM Plex Mono', monospace",
            }}>
              {i + 1}
            </div>

            {/* Content */}
            <div style={{ flex: 1 }}>
              <div style={{
                display: "flex", alignItems: "center", gap: 8,
                marginBottom: 8, flexWrap: "wrap",
              }}>
                <span style={{
                  fontFamily: "'IBM Plex Mono', monospace",
                  fontSize: 11, color: "#58a6ff", fontWeight: 600,
                }}>
                  {r.item_code}
                </span>
                <span style={{ fontSize: 13, fontWeight: 600, color: "#e6edf3" }}>
                  {r.item_label_en}
                </span>
                <GapBadge gap={r.gap} />
                <SeverityBadge sev={r.gap_severity} />
              </div>
              <div style={{ fontSize: 12, color: "#8b949e", lineHeight: 1.65 }}>
                {r.suggestion_en}
              </div>
              {r.suggestion_nl !== r.suggestion_en && (
                <div style={{
                  marginTop: 8, padding: "8px 10px", borderRadius: 5,
                  background: "#0d1117", border: "1px solid #21262d",
                  fontSize: 11, color: "#8b949e", lineHeight: 1.5,
                  fontStyle: "italic",
                }}>
                  🇳🇱 {r.suggestion_nl}
                </div>
              )}
            </div>
          </div>
        );
      })}
    </div>
  );
}
