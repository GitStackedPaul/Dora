import { useState } from 'react';
import { TAG_MAP } from '../data/obligations.js';
import { FileIcon } from './Icons.jsx';

export default function UploadTab({ uploadedDocs, setUploadedDocs }) {
  const [dragOver, setDragOver] = useState(false);

  const processFiles = (files) => {
    const arr = Array.from(files);
    const newDocs = arr.map((f, i) => {
      const lower = f.name.toLowerCase();
      const inferredTags = [];
      for (const [key, tags] of Object.entries(TAG_MAP)) {
        if (lower.includes(key)) inferredTags.push(...tags);
      }
      return {
        ref: `[${uploadedDocs.length + i + 1}]`,
        filename: f.name,
        inferred_tags: [...new Set(inferredTags)].sort(),
      };
    });
    setUploadedDocs((prev) => [...prev, ...newDocs]);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    setDragOver(false);
    processFiles(e.dataTransfer.files);
  };

  const handleInput = (e) => {
    processFiles(e.target.files);
    e.target.value = "";
  };

  const removeDoc = (idx) =>
    setUploadedDocs((prev) => prev.filter((_, j) => j !== idx));

  const clearAll = () => setUploadedDocs([]);

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Drop zone */}
      <div
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        onClick={() => document.getElementById("doraFileInput").click()}
        style={{
          border: `2px dashed ${dragOver ? "#58a6ff" : "#30363d"}`,
          borderRadius: 10, padding: "40px 24px", textAlign: "center",
          background: dragOver ? "rgba(88,166,255,0.06)" : "#161b22",
          cursor: "pointer", transition: "all 0.15s ease",
        }}
      >
        <input
          id="doraFileInput"
          type="file"
          multiple
          accept=".pdf,.docx,.doc,.xlsx,.pptx"
          style={{ display: "none" }}
          onChange={handleInput}
        />
        <div style={{ fontSize: 32, marginBottom: 12 }}>📂</div>
        <div style={{ fontSize: 14, color: "#e6edf3", fontWeight: 500, marginBottom: 6 }}>
          Drop policy documents here or click to browse
        </div>
        <div style={{ fontSize: 11, color: "#8b949e" }}>
          Supports PDF, DOCX, XLSX, PPTX — filenames are parsed to infer DORA tags automatically
        </div>
      </div>

      {/* Hint box */}
      <div style={{
        padding: "10px 14px", borderRadius: 8, background: "rgba(88,166,255,0.06)",
        border: "1px solid rgba(88,166,255,0.15)", fontSize: 11, color: "#8b949e",
        lineHeight: 1.6,
      }}>
        <strong style={{ color: "#58a6ff" }}>Tag inference:</strong> Filenames containing keywords like{" "}
        <code style={{ background: "#21262d", padding: "0 4px", borderRadius: 3 }}>risk</code>,{" "}
        <code style={{ background: "#21262d", padding: "0 4px", borderRadius: 3 }}>incident</code>,{" "}
        <code style={{ background: "#21262d", padding: "0 4px", borderRadius: 3 }}>backup</code>,{" "}
        <code style={{ background: "#21262d", padding: "0 4px", borderRadius: 3 }}>outsourcing</code>, etc.
        are automatically matched to DORA obligations. The gap analysis re-runs instantly.
      </div>

      {/* Document list */}
      {uploadedDocs.length > 0 && (
        <div style={{
          background: "#161b22", borderRadius: 10,
          border: "1px solid #21262d", overflow: "hidden",
        }}>
          <div style={{
            display: "flex", justifyContent: "space-between", alignItems: "center",
            padding: "8px 16px", background: "#0d1117",
            borderBottom: "1px solid #21262d",
          }}>
            <div style={{
              display: "grid", gridTemplateColumns: "1fr 220px 36px",
              gap: 8, flex: 1,
            }}>
              {["Filename", "Inferred Tags", ""].map((h) => (
                <div key={h} style={{
                  fontSize: 10, fontWeight: 600, color: "#8b949e",
                  textTransform: "uppercase", letterSpacing: "0.06em",
                }}>
                  {h}
                </div>
              ))}
            </div>
            <button
              onClick={clearAll}
              style={{
                fontSize: 10, padding: "2px 8px", borderRadius: 4,
                border: "1px solid rgba(248,81,73,0.3)", background: "rgba(248,81,73,0.08)",
                color: "#f85149", cursor: "pointer", marginLeft: 16,
              }}
            >
              Clear all
            </button>
          </div>

          {uploadedDocs.map((d, i) => (
            <div
              key={i}
              style={{
                display: "grid", gridTemplateColumns: "1fr 220px 36px",
                padding: "9px 16px", gap: 8, alignItems: "center",
                borderBottom: i < uploadedDocs.length - 1 ? "1px solid #21262d" : "none",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                <FileIcon size={13} />
                <span style={{ fontSize: 12, color: "#e6edf3" }}>{d.filename}</span>
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 3 }}>
                {d.inferred_tags.length === 0 ? (
                  <span style={{ fontSize: 10, color: "#484f58", fontStyle: "italic" }}>none inferred</span>
                ) : d.inferred_tags.slice(0, 5).map((t) => (
                  <span key={t} style={{
                    fontSize: 10, padding: "1px 5px", borderRadius: 3,
                    background: "#21262d", color: "#8b949e", border: "1px solid #30363d",
                  }}>
                    {t}
                  </span>
                ))}
              </div>
              <button
                onClick={() => removeDoc(i)}
                style={{
                  padding: "3px 6px", borderRadius: 4,
                  border: "1px solid #30363d", background: "transparent",
                  color: "#f85149", cursor: "pointer", fontSize: 11,
                }}
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
