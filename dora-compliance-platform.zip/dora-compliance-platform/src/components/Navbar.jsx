import { ShieldIcon, DownloadIcon } from './Icons.jsx';

export default function Navbar({ clientProfile, setClientProfile, onExport }) {
  return (
    <nav style={{
      background: "#161b22",
      borderBottom: "1px solid #21262d",
      padding: "0 24px",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      height: 56,
      flexShrink: 0,
      position: "sticky",
      top: 0,
      zIndex: 100,
    }}>
      {/* Left: Logo + Title */}
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <div style={{
          width: 28, height: 28, borderRadius: 6, flexShrink: 0,
          background: "linear-gradient(135deg, #58a6ff 0%, #a371f7 100%)",
          display: "flex", alignItems: "center", justifyContent: "center",
          color: "white",
        }}>
          <ShieldIcon size={14} />
        </div>
        <span style={{ fontWeight: 700, fontSize: 14, letterSpacing: "-0.01em", color: "#e6edf3" }}>
          DORA Compliance
        </span>
        <span style={{ color: "#30363d", fontSize: 16, margin: "0 4px" }}>|</span>
        <span style={{
          fontSize: 11, color: "#8b949e",
          fontFamily: "'IBM Plex Mono', monospace",
          letterSpacing: "0.02em",
        }}>
          EU 2022/2554
        </span>
      </div>

      {/* Right: Profile toggle + Export */}
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <span style={{ fontSize: 11, color: "#8b949e", marginRight: 2 }}>Profile:</span>
        {[
          { id: "standard", label: "Standard" },
          { id: "micro_entity", label: "Micro Entity" },
        ].map((p) => (
          <button
            key={p.id}
            onClick={() => setClientProfile(p.id)}
            style={{
              padding: "4px 12px", borderRadius: 20, fontSize: 11, fontWeight: 600,
              border: clientProfile === p.id
                ? "1px solid rgba(88,166,255,0.5)"
                : "1px solid #30363d",
              background: clientProfile === p.id
                ? "rgba(88,166,255,0.12)"
                : "transparent",
              color: clientProfile === p.id ? "#58a6ff" : "#8b949e",
              cursor: "pointer", transition: "all 0.15s ease",
            }}
          >
            {p.label}
          </button>
        ))}
        <button
          onClick={onExport}
          style={{
            display: "flex", alignItems: "center", gap: 5,
            padding: "5px 12px", borderRadius: 6,
            border: "1px solid #30363d", background: "transparent",
            color: "#8b949e", cursor: "pointer", fontSize: 12,
            transition: "all 0.15s ease",
          }}
          onMouseOver={(e) => { e.currentTarget.style.color = "#e6edf3"; e.currentTarget.style.borderColor = "#484f58"; }}
          onMouseOut={(e) => { e.currentTarget.style.color = "#8b949e"; e.currentTarget.style.borderColor = "#30363d"; }}
        >
          <DownloadIcon size={13} /> Export JSON
        </button>
      </div>
    </nav>
  );
}
