import { useState, useMemo } from 'react';
import { OBLIGATIONS, SAMPLE_DOCS } from './data/obligations.js';
import { runGapAnalysis, generateRoadmap } from './lib/gapAnalysis.js';
import Navbar from './components/Navbar.jsx';
import Sidebar from './components/Sidebar.jsx';
import StatsBar from './components/StatsBar.jsx';
import GapTable from './components/GapTable.jsx';
import RoadmapTab from './components/RoadmapTab.jsx';
import UploadTab from './components/UploadTab.jsx';

export default function App() {
  const [clientProfile, setClientProfile] = useState('standard');
  const [uploadedDocs, setUploadedDocs] = useState(SAMPLE_DOCS);
  const [searchQuery, setSearchQuery] = useState('');
  const [gapFilter, setGapFilter] = useState([]);
  const [severityFilter, setSeverityFilter] = useState([]);
  const [activeTab, setActiveTab] = useState('gap');

  // Run gap analysis whenever docs or profile change
  const gapResults = useMemo(
    () => runGapAnalysis(OBLIGATIONS, uploadedDocs, clientProfile),
    [uploadedDocs, clientProfile]
  );

  const roadmap = useMemo(() => generateRoadmap(gapResults), [gapResults]);

  const stats = useMemo(() => ({
    total:         gapResults.filter(r => r.applicability === 'Applicable').length,
    gaps:          gapResults.filter(r => r.gap === 'Gap').length,
    partial:       gapResults.filter(r => r.gap === 'Partial gap').length,
    noGap:         gapResults.filter(r => r.gap === 'No gap').length,
    notApplicable: gapResults.filter(r => r.applicability === 'Not Applicable').length,
  }), [gapResults]);

  // Filtered rows for the table
  const filteredRows = useMemo(() => {
    return gapResults.filter(r => {
      const q = searchQuery.toLowerCase();
      const matchSearch = !q ||
        r.item_code.toLowerCase().includes(q) ||
        r.item_label_en.toLowerCase().includes(q) ||
        r.item_label_nl.toLowerCase().includes(q);
      const matchGap = gapFilter.length === 0 || gapFilter.includes(r.gap);
      const matchSev = severityFilter.length === 0 || severityFilter.includes(r.gap_severity);
      return matchSearch && matchGap && matchSev;
    });
  }, [gapResults, searchQuery, gapFilter, severityFilter]);

  const toggleGapFilter = (val) =>
    setGapFilter(f => f.includes(val) ? f.filter(x => x !== val) : [...f, val]);
  const toggleSevFilter = (val) =>
    setSeverityFilter(f => f.includes(val) ? f.filter(x => x !== val) : [...f, val]);
  const clearFilters = () => { setGapFilter([]); setSeverityFilter([]); setSearchQuery(''); };

  const handleExport = () => {
    const blob = new Blob([JSON.stringify(gapResults, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href = url;
    a.download = 'dora_gap_output.json'; a.click();
    URL.revokeObjectURL(url);
  };

  const TABS = [
    { id: 'gap',      label: 'Gap Analysis',        count: filteredRows.length },
    { id: 'roadmap',  label: 'Improvement Roadmap',  count: roadmap.length },
    { id: 'upload',   label: 'Policy Documents',     count: uploadedDocs.length },
  ];

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: '#0d1117' }}>
      <Navbar
        clientProfile={clientProfile}
        setClientProfile={setClientProfile}
        onExport={handleExport}
      />

      <div style={{ display: 'flex', flex: 1, overflow: 'hidden' }}>
        <Sidebar
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          gapFilter={gapFilter}
          toggleGapFilter={toggleGapFilter}
          severityFilter={severityFilter}
          toggleSevFilter={toggleSevFilter}
          gapResults={gapResults}
          uploadedDocs={uploadedDocs}
          onClearFilters={clearFilters}
        />

        <main style={{ flex: 1, overflowY: 'auto', padding: '24px' }}>
          <StatsBar stats={stats} />

          {/* Tabs */}
          <div style={{ display: 'flex', gap: 2, marginBottom: 16, borderBottom: '1px solid #21262d' }}>
            {TABS.map(t => (
              <button
                key={t.id}
                onClick={() => setActiveTab(t.id)}
                style={{
                  padding: '8px 14px', fontSize: 12, fontWeight: 500, cursor: 'pointer',
                  background: 'transparent', border: 'none',
                  color: activeTab === t.id ? '#e6edf3' : '#8b949e',
                  borderBottom: activeTab === t.id ? '2px solid #58a6ff' : '2px solid transparent',
                  display: 'flex', alignItems: 'center', gap: 6,
                  marginBottom: -1, transition: 'color 0.15s',
                }}
              >
                {t.label}
                <span style={{
                  fontSize: 10, padding: '1px 6px', borderRadius: 10,
                  background: activeTab === t.id ? 'rgba(88,166,255,0.15)' : '#21262d',
                  color: activeTab === t.id ? '#58a6ff' : '#8b949e',
                  transition: 'all 0.15s',
                }}>
                  {t.count}
                </span>
              </button>
            ))}
          </div>

          {activeTab === 'gap'     && <GapTable rows={filteredRows} />}
          {activeTab === 'roadmap' && <RoadmapTab roadmap={roadmap} />}
          {activeTab === 'upload'  && <UploadTab uploadedDocs={uploadedDocs} setUploadedDocs={setUploadedDocs} />}
        </main>
      </div>
    </div>
  );
}
